# DOMINUS — API Reference

Base URL: `https://your-api.railway.app`  
All protected routes require: `Authorization: Bearer <supabase_jwt>`

---

## Authentication

All routes under `/api/*` (except `/api/auth` and `/api/stripe/webhook`) require a valid Supabase JWT.

The mobile app obtains this token via `supabase.auth.getSession()` and attaches it automatically via `api.ts`.

---

## Endpoints

### Properties

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET    | `/api/properties` | List all accessible properties |
| GET    | `/api/properties/:id` | Get single property with full details |
| POST   | `/api/properties` | Create property (auto-seeds checklist + seasonal tasks) |
| PATCH  | `/api/properties/:id` | Update property fields |
| DELETE | `/api/properties/:id` | Delete property (owner only) |

**POST /api/properties body:**
```json
{
  "name": "Harlow House",
  "address": "14 Harlow Square, London",
  "postcode": "EC1A 1BB",
  "geoLat": 51.5225,
  "geoLng": -0.0856
}
```

---

### Contracts

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET    | `/api/contracts/:propertyId` | Get property contract |
| PUT    | `/api/contracts/:propertyId` | Update contract schedule |
| POST   | `/api/contracts/:propertyId/subscribe` | Create Stripe subscription |

**PUT /api/contracts/:propertyId body:**
```json
{
  "plan": "weekly",
  "tier": "Premium",
  "customIntervalDays": null,
  "contractHolder": "Mr. T. Harlow",
  "inspectorNotes": "Check wine cellar on every visit."
}
```

---

### Inspection Visits

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET    | `/api/visits?propertyId=&weekKey=` | List visits |
| POST   | `/api/visits` | Start a visit (or return existing for week) |
| PATCH  | `/api/visits/:id/result` | Update single checklist item |
| POST   | `/api/visits/:id/submit` | Submit visit, calculate score, notify owner |

**Week key format:** `2026-W25` (ISO week number)

**PATCH /api/visits/:id/result body:**
```json
{
  "templateId": "uuid",
  "status": "pass",
  "inspectorNote": "All clear",
  "photoUrl": null
}
```

**POST /api/visits/:id/submit response:**
```json
{
  "data": {
    "score": 87,
    "status": "attention",
    "failCount": 2
  }
}
```

---

### Photos

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET    | `/api/photos?propertyId=` | List property photos |
| POST   | `/api/photos` | Upload photo (multipart/form-data) |
| DELETE | `/api/photos/:id` | Delete photo |

**POST /api/photos fields:**
- `file` — image file (JPEG/PNG, max 10MB)
- `propertyId` — required
- `label` — e.g. "Front facade"
- `geoLat`, `geoLng` — device GPS coordinates
- `visitId` — optional, links photo to a visit

---

### Seasonal

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET    | `/api/seasonal?propertyId=&season=` | Get tasks with completion status |
| POST   | `/api/seasonal/task` | Add custom task |
| PATCH  | `/api/seasonal/task/:id` | Edit or deactivate task |
| POST   | `/api/seasonal/complete` | Mark task done/undone |

**Season values:** `spring` `summer` `fall` `winter`

---

### Messages

Handled via Supabase Realtime directly from the mobile client (see `api.ts` `MessageService`).  
Server-side operations (if needed) can be added to `/api/messages`.

---

## Score Calculation

Inspection scores are weighted by priority:

| Priority | Weight |
|----------|--------|
| Critical | 4      |
| High     | 3      |
| Medium   | 2      |
| Low      | 1      |

`score = (sum of weights for passed items) / (total weights) × 100`

Property status is then set automatically:
- Score ≥ 90 → `good`
- Score 70–89 → `attention`
- Score < 70 → `overdue`

---

## Error Format

All errors follow this shape:
```json
{
  "error": {
    "code": "VALIDATION",
    "message": "name and address are required",
    "details": {}
  }
}
```

Common error codes: `UNAUTHORIZED`, `INVALID_TOKEN`, `VALIDATION`, `NOT_FOUND`, `FETCH_ERROR`, `CREATE_ERROR`, `UPDATE_ERROR`, `DELETE_ERROR`, `STRIPE_ERROR`
