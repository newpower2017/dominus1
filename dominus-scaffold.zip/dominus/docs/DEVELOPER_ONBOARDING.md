# DOMINUS — Developer Onboarding Checklist

Work through this list top to bottom. Each step must be complete before the next.

---

## Phase 1 — Environment (Day 1)

- [ ] Clone the repo and run `yarn install`
- [ ] Create a Supabase project at supabase.com (free tier is fine for dev)
- [ ] Copy `.env.example` files and fill in Supabase URL + keys
- [ ] Run `supabase start` to boot local Supabase instance
- [ ] Run migrations: `supabase db push`
- [ ] Run seed: `yarn db:seed`
- [ ] Generate TypeScript types: `yarn db:types`
- [ ] Start API: `yarn api` → verify `GET /health` returns `{"status":"ok"}`
- [ ] Start mobile: `yarn mobile` → app loads on simulator

---

## Phase 2 — Auth & Profiles (Days 2–3)

- [ ] Build sign-up screen with role selector (Manager / Homeowner / Inspector)
- [ ] Build sign-in screen
- [ ] Implement session persistence via Expo SecureStore
- [ ] Verify profile is auto-created in Supabase on signup (check `handle_new_user` trigger)
- [ ] Add push token registration on app launch (store in `profiles.push_token`)
- [ ] Protect routes — redirect to sign-in if no session

---

## Phase 3 — Properties (Days 4–6)

- [ ] Dashboard screen — fetch and display property list
- [ ] Property cards with thumbnail, tier badge, score, last-check date
- [ ] Create property flow (name, address, postcode, optional geo)
- [ ] Verify checklist templates auto-seeded on creation (10 items)
- [ ] Verify seasonal tasks auto-seeded on creation (27 tasks across 4 seasons)
- [ ] Property detail screen with 4-tab layout (Checks / Seasonal / Schedule / Photos)

---

## Phase 4 — Checklist & Visits (Days 7–10)

- [ ] Weekly checklist panel with week navigator (← This week →)
- [ ] Tap to cycle status: pending → pass → fail → pending
- [ ] Progress bar and pass/fail/pending counts
- [ ] Add / edit / delete checklist template items
- [ ] Category filter pills
- [ ] Start visit on entering checklist (POST /api/visits with GPS coords)
- [ ] Real GPS geo-verification via `expo-location`
- [ ] Submit visit (POST /api/visits/:id/submit) → score recalculates → property status updates

---

## Phase 5 — Seasonal Checks (Days 11–12)

- [ ] Seasonal panel with 4-season tab selector
- [ ] Progress per season with accent colours
- [ ] Toggle task done/undone (POST /api/seasonal/complete)
- [ ] Add custom task per property per season
- [ ] Edit / delete (soft delete) tasks
- [ ] Submit seasonal report button

---

## Phase 6 — Photos (Days 13–14)

- [ ] Photo gallery grid in property profile
- [ ] Camera capture via `expo-camera`
- [ ] Upload from library via `expo-image-picker`
- [ ] Geo-stamp on save (attach GPS coordinates from `expo-location`)
- [ ] Label input before saving
- [ ] Lightbox viewer on tap
- [ ] Delete with confirmation

---

## Phase 7 — Schedule & Contracts (Days 15–16)

- [ ] Schedule tab: show active plan card with tier colour, day interval, visits-per-month bar
- [ ] Upcoming visits list (calculated from interval + today)
- [ ] Edit Plan modal: radio buttons for Weekly/Bi-weekly/Monthly/Custom
- [ ] Custom day stepper + preset buttons (7d/10d/14d/21d/30d)
- [ ] Save → PUT /api/contracts/:propertyId
- [ ] Contract holder name and inspector notes fields

---

## Phase 8 — Messages (Days 17–18)

- [ ] Conversation list per property
- [ ] Chat thread with real-time messages (Supabase Realtime)
- [ ] Unread count badge on nav tab
- [ ] Send message (text only for V1)
- [ ] Mark read on open

---

## Phase 9 — Reports & Notifications (Days 19–20)

- [ ] Reports list with geo-verified badge, score, issue count
- [ ] PDF generation (use `pdf-lib` in API) — triggered on visit submit
- [ ] Download / view PDF
- [ ] Notification bell with unread count
- [ ] Notification list (overdue check, issue flagged, message, report ready)
- [ ] Mark all read

---

## Phase 10 — Payments (Days 21–22)

- [ ] Stripe product + price setup in Stripe dashboard (3 tiers)
- [ ] Paste price IDs into API `.env`
- [ ] Upgrade plan flow → POST /api/contracts/:propertyId/subscribe
- [ ] Stripe payment sheet via `stripe-react-native`
- [ ] Stripe webhook → update contract on subscription events

---

## Phase 11 — Polish & Launch (Days 23–28)

- [ ] Training centre screen (list courses, mark complete)
- [ ] Empty states for all lists
- [ ] Error handling and offline messaging
- [ ] EAS Build setup: `eas build:configure`
- [ ] TestFlight (iOS) and Internal Testing (Android) build
- [ ] App Store screenshots (6.5" iPhone + 12.9" iPad)
- [ ] App Store listing copy + keywords
- [ ] Submit for review

---

## Key Contacts / Accounts to Create

| Service | URL | Notes |
|---------|-----|-------|
| Supabase | supabase.com | Create project, get URL + keys |
| Stripe | stripe.com | Create products + prices for 3 tiers |
| Railway | railway.app | Deploy API (connect GitHub repo) |
| Apple Developer | developer.apple.com | £99/year for App Store |
| Google Play | play.google.com/console | £25 one-time fee |
| Expo EAS | expo.dev | Free tier fine for V1 |
