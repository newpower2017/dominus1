# DOMINUS — Premium Estate Management Platform

## Project Overview
Dominus is a mobile-first property management app for property managers, homeowners, and estate inspectors. Built with React Native (Expo), Node.js API, and Supabase.

---

## Monorepo Structure

```
dominus/
├── apps/
│   ├── mobile/          # React Native (Expo) — iOS & Android
│   └── api/             # Node.js + Express REST API
├── packages/
│   ├── shared/          # Shared TypeScript types, constants, validators
│   └── ui/              # Shared UI components (optional future use)
├── supabase/
│   ├── migrations/      # SQL migrations (run in order)
│   ├── functions/       # Supabase Edge Functions
│   └── seed/            # Seed data for development
└── docs/                # Architecture decisions, API docs
```

---

## Tech Stack

| Layer            | Technology                        |
|------------------|-----------------------------------|
| Mobile           | React Native + Expo SDK 50        |
| Navigation       | Expo Router (file-based)          |
| State Management | Zustand                           |
| Backend          | Node.js + Express                 |
| Database         | Supabase (PostgreSQL)             |
| Auth             | Supabase Auth (JWT)               |
| File Storage     | Supabase Storage (photos)         |
| Push Alerts      | Expo Notifications + APNs/FCM     |
| PDF Generation   | pdf-lib (API-side)                |
| Payments         | Stripe                            |
| Deployment       | Railway (API) + EAS Build (mobile)|

---

## Quick Start for Developers

### 1. Prerequisites
- Node.js 18+
- Yarn 1.22+
- Expo CLI: `npm install -g expo-cli`
- Supabase CLI: `npm install -g supabase`
- iOS Simulator (Mac) or Android Studio

### 2. Clone & Install
```bash
git clone https://github.com/your-org/dominus.git
cd dominus
yarn install
```

### 3. Environment Setup
```bash
# Copy environment templates
cp apps/mobile/.env.example apps/mobile/.env
cp apps/api/.env.example apps/api/.env
```
Fill in your Supabase URL, anon key, service role key, and Stripe keys.

### 4. Database Setup
```bash
# Start local Supabase
supabase start

# Run all migrations in order
supabase db push

# Seed development data
yarn db:seed

# Generate TypeScript types from schema
yarn db:types
```

### 5. Run Development Servers
```bash
# Terminal 1 — API server
yarn api

# Terminal 2 — Mobile app
yarn mobile
```

---

## Environment Variables

### Mobile (`apps/mobile/.env`)
```
EXPO_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
EXPO_PUBLIC_API_URL=http://localhost:3001
EXPO_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_xxxx
```

### API (`apps/api/.env`)
```
SUPABASE_URL=https://xxxx.supabase.co
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
STRIPE_SECRET_KEY=sk_test_xxxx
STRIPE_WEBHOOK_SECRET=whsec_xxxx
PORT=3001
JWT_SECRET=your-jwt-secret
```

---

## Key Design Decisions

1. **Supabase for everything auth/storage** — reduces infrastructure complexity for V1.
2. **API layer over direct Supabase calls** — keeps business logic server-side, easier to audit and secure.
3. **Monorepo** — shared types prevent drift between mobile and API.
4. **Expo EAS Build** — handles iOS/Android builds in CI without a Mac farm.
5. **Zustand over Redux** — simpler state management for the scale of V1.

---

## Deployment

### API → Railway
1. Connect GitHub repo to Railway
2. Set environment variables in Railway dashboard
3. Railway auto-deploys on push to `main`

### Mobile → App Stores (via EAS)
```bash
cd apps/mobile
eas build --platform all --profile production
eas submit --platform all
```

---

## Contract Tiers & Billing

| Tier      | Frequency     | Monthly Price |
|-----------|---------------|---------------|
| Essential | Monthly       | £29/property  |
| Standard  | Bi-weekly     | £49/property  |
| Premium   | Weekly        | £89/property  |
| Bespoke   | Custom        | Quote         |

Stripe handles subscriptions. Each property has its own Stripe subscription item.
