-- ============================================================
-- DOMINUS — Seed Data (development only)
-- Creates sample users, properties, and checklist templates
-- Run: supabase db seed  (after migrations)
-- ============================================================

-- Note: In production, auth users are created via Supabase Auth.
-- These seed profiles assume you've manually created auth users
-- with these UUIDs in your local Supabase instance.

-- ============================================================
-- TRAINING COURSES
-- ============================================================

INSERT INTO training_courses (title, level, duration_minutes, sort_order) VALUES
  ('Estate Walk-Through Protocol',    'Foundation',    15, 1),
  ('Water & Damp Leak Detection',     'Intermediate',  22, 2),
  ('Insurance Compliance Standards',  'Intermediate',  30, 3),
  ('Advanced Estate Assessment',      'Professional',  50, 4);

-- ============================================================
-- DEFAULT CHECKLIST ITEMS (inserted per-property at creation)
-- Used as a reference — actual insertion happens in API service
-- ============================================================

-- This is referenced by the API's PropertyService.createProperty()
-- to auto-populate checklist_templates for each new property.

COMMENT ON TABLE checklist_templates IS
  'Default items: Security×2, Water×2, Electrical×2, Exterior×2, Interior×2.
   See apps/api/src/services/PropertyService.ts DEFAULT_CHECKLIST_ITEMS.';

-- ============================================================
-- DEFAULT SEASONAL TASKS (inserted per-property at creation)
-- ============================================================

COMMENT ON TABLE seasonal_tasks IS
  'Default spring×8, summer×6, fall×7, winter×6 tasks.
   See apps/api/src/services/PropertyService.ts DEFAULT_SEASONAL_TASKS.';
