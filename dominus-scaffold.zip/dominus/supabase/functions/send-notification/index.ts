// supabase/functions/send-notification/index.ts
// Supabase Edge Function — called server-side to send push notifications
// Deploy: supabase functions deploy send-notification

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const EXPO_PUSH_URL = 'https://exp.host/--/api/v2/push/send';

serve(async (req) => {
  const { userId, title, body, data } = await req.json();

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  );

  // Get user's push token (stored in profiles or a separate push_tokens table)
  const { data: profile } = await supabase
    .from('profiles')
    .select('push_token')
    .eq('id', userId)
    .single();

  if (!profile?.push_token) {
    return new Response(JSON.stringify({ error: 'No push token' }), { status: 400 });
  }

  // Send via Expo Push API
  const response = await fetch(EXPO_PUSH_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      to: profile.push_token,
      title,
      body,
      data: data || {},
      sound: 'default',
      priority: 'high',
    }),
  });

  // Store notification in database
  await supabase.from('notifications').insert({
    user_id: userId,
    title,
    body,
    type: data?.type || 'general',
    data: data || {},
  });

  return new Response(JSON.stringify({ sent: true }), { status: 200 });
});
