-- ============================================================
-- DOMINUS — Supabase Migration 001
-- Core Schema: Users, Properties, Checklists, Reports
-- Run: supabase db push
-- ============================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis";   -- for geo-location
CREATE EXTENSION IF NOT EXISTS "pg_cron";   -- for scheduled checks

-- ============================================================
-- ENUMS
-- ============================================================

CREATE TYPE user_role AS ENUM ('manager', 'homeowner', 'inspector');
CREATE TYPE property_status AS ENUM ('good', 'attention', 'overdue');
CREATE TYPE visit_plan AS ENUM ('weekly', 'biweekly', 'monthly', 'custom');
CREATE TYPE contract_tier AS ENUM ('Essential', 'Standard', 'Premium', 'Bespoke');
CREATE TYPE checklist_status AS ENUM ('pending', 'pass', 'fail');
CREATE TYPE priority_level AS ENUM ('critical', 'high', 'medium', 'low');
CREATE TYPE checklist_category AS ENUM ('Security', 'Water', 'Electrical', 'Exterior', 'Interior', 'Other');
CREATE TYPE season_key AS ENUM ('spring', 'summer', 'fall', 'winter');
CREATE TYPE report_type AS ENUM ('routine', 'maintenance', 'insurance', 'seasonal');

-- ============================================================
-- PROFILES (extends Supabase auth.users)
-- ============================================================

CREATE TABLE profiles (
  id            UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name     TEXT NOT NULL,
  role          user_role NOT NULL DEFAULT 'homeowner',
  phone         TEXT,
  avatar_url    TEXT,
  stripe_customer_id TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, full_name, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email),
    COALESCE((NEW.raw_user_meta_data->>'role')::user_role, 'homeowner')
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ============================================================
-- PROPERTIES
-- ============================================================

CREATE TABLE properties (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name            TEXT NOT NULL,
  address         TEXT NOT NULL,
  postcode        TEXT,
  country         TEXT DEFAULT 'GB',
  geo_lat         DECIMAL(10, 8),
  geo_lng         DECIMAL(11, 8),
  illustration_id INTEGER DEFAULT 1,  -- maps to SVG illustrations 1-3
  status          property_status NOT NULL DEFAULT 'good',
  score           INTEGER NOT NULL DEFAULT 100 CHECK (score BETWEEN 0 AND 100),
  last_check_at   TIMESTAMPTZ,
  owner_id        UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Index for fast lookups by owner
CREATE INDEX idx_properties_owner ON properties(owner_id);

-- ============================================================
-- PROPERTY CONTRACTS (schedule + billing)
-- ============================================================

CREATE TABLE property_contracts (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  property_id         UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
  plan                visit_plan NOT NULL DEFAULT 'monthly',
  tier                contract_tier NOT NULL DEFAULT 'Essential',
  custom_interval_days INTEGER,            -- only if plan = 'custom'
  contract_holder     TEXT,               -- owner name on contract
  inspector_notes     TEXT,               -- access codes, instructions
  start_date          DATE NOT NULL DEFAULT CURRENT_DATE,
  stripe_subscription_id TEXT,
  stripe_price_id     TEXT,
  active              BOOLEAN NOT NULL DEFAULT TRUE,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(property_id)  -- one active contract per property
);

CREATE INDEX idx_contracts_property ON property_contracts(property_id);

-- ============================================================
-- PROPERTY TEAM (who can access each property)
-- ============================================================

CREATE TABLE property_members (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  property_id   UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
  user_id       UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  role          user_role NOT NULL DEFAULT 'inspector',
  invited_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  accepted_at   TIMESTAMPTZ,
  UNIQUE(property_id, user_id)
);

-- ============================================================
-- CHECKLIST TEMPLATES (per-property, customisable)
-- ============================================================

CREATE TABLE checklist_templates (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  property_id UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
  title       TEXT NOT NULL,
  category    checklist_category NOT NULL DEFAULT 'Security',
  priority    priority_level NOT NULL DEFAULT 'medium',
  active      BOOLEAN NOT NULL DEFAULT TRUE,
  sort_order  INTEGER NOT NULL DEFAULT 0,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_checklist_templates_property ON checklist_templates(property_id);

-- ============================================================
-- INSPECTION VISITS
-- ============================================================

CREATE TABLE inspection_visits (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  property_id     UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
  inspector_id    UUID REFERENCES profiles(id),
  week_key        TEXT NOT NULL,   -- format: "2026-W25"
  visit_date      DATE NOT NULL DEFAULT CURRENT_DATE,
  geo_lat         DECIMAL(10, 8),
  geo_lng         DECIMAL(11, 8),
  geo_verified    BOOLEAN NOT NULL DEFAULT FALSE,
  geo_timestamp   TIMESTAMPTZ,
  score           INTEGER CHECK (score BETWEEN 0 AND 100),
  submitted_at    TIMESTAMPTZ,
  report_url      TEXT,            -- PDF stored in Supabase Storage
  notes           TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(property_id, week_key)
);

CREATE INDEX idx_visits_property ON inspection_visits(property_id);
CREATE INDEX idx_visits_week ON inspection_visits(week_key);

-- ============================================================
-- CHECKLIST RESULTS (per visit, per template item)
-- ============================================================

CREATE TABLE checklist_results (
  id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  visit_id              UUID NOT NULL REFERENCES inspection_visits(id) ON DELETE CASCADE,
  template_id           UUID NOT NULL REFERENCES checklist_templates(id) ON DELETE CASCADE,
  status                checklist_status NOT NULL DEFAULT 'pending',
  inspector_note        TEXT,
  photo_url             TEXT,
  recorded_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(visit_id, template_id)
);

CREATE INDEX idx_checklist_results_visit ON checklist_results(visit_id);

-- ============================================================
-- PROPERTY PHOTOS
-- ============================================================

CREATE TABLE property_photos (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  property_id   UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
  visit_id      UUID REFERENCES inspection_visits(id),
  storage_path  TEXT NOT NULL,     -- Supabase Storage path
  public_url    TEXT NOT NULL,
  label         TEXT,
  geo_lat       DECIMAL(10, 8),
  geo_lng       DECIMAL(11, 8),
  geo_timestamp TIMESTAMPTZ,
  uploaded_by   UUID REFERENCES profiles(id),
  uploaded_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_photos_property ON property_photos(property_id);

-- ============================================================
-- SEASONAL CHECKS (per-property, per-season)
-- ============================================================

CREATE TABLE seasonal_tasks (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  property_id UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
  season      season_key NOT NULL,
  title       TEXT NOT NULL,
  active      BOOLEAN NOT NULL DEFAULT TRUE,
  sort_order  INTEGER NOT NULL DEFAULT 0,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_seasonal_tasks_property ON seasonal_tasks(property_id, season);

CREATE TABLE seasonal_completions (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  task_id     UUID NOT NULL REFERENCES seasonal_tasks(id) ON DELETE CASCADE,
  year        INTEGER NOT NULL,
  done        BOOLEAN NOT NULL DEFAULT FALSE,
  done_at     TIMESTAMPTZ,
  done_by     UUID REFERENCES profiles(id),
  UNIQUE(task_id, year)
);

-- ============================================================
-- MESSAGES
-- ============================================================

CREATE TABLE conversations (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  property_id   UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
  subject       TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE messages (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  sender_id       UUID NOT NULL REFERENCES profiles(id),
  body            TEXT NOT NULL,
  read_by         UUID[] DEFAULT '{}',
  attachment_url  TEXT,
  sent_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_messages_conversation ON messages(conversation_id);

-- ============================================================
-- NOTIFICATIONS
-- ============================================================

CREATE TABLE notifications (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  property_id UUID REFERENCES properties(id),
  title       TEXT NOT NULL,
  body        TEXT NOT NULL,
  type        TEXT NOT NULL,  -- 'overdue_check', 'issue_flagged', 'message', 'report_ready'
  read        BOOLEAN NOT NULL DEFAULT FALSE,
  data        JSONB DEFAULT '{}',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_notifications_user ON notifications(user_id, read);

-- ============================================================
-- TRAINING
-- ============================================================

CREATE TABLE training_courses (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title       TEXT NOT NULL,
  level       TEXT NOT NULL,  -- 'Foundation', 'Intermediate', 'Professional'
  duration_minutes INTEGER NOT NULL,
  content_url TEXT,
  active      BOOLEAN NOT NULL DEFAULT TRUE,
  sort_order  INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE training_completions (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  course_id   UUID NOT NULL REFERENCES training_courses(id) ON DELETE CASCADE,
  completed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, course_id)
);

-- ============================================================
-- UPDATED_AT TRIGGER (auto-update timestamps)
-- ============================================================

CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER set_profiles_updated_at         BEFORE UPDATE ON profiles         FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER set_properties_updated_at       BEFORE UPDATE ON properties       FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER set_contracts_updated_at        BEFORE UPDATE ON property_contracts FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER set_templates_updated_at        BEFORE UPDATE ON checklist_templates FOR EACH ROW EXECUTE FUNCTION set_updated_at();
