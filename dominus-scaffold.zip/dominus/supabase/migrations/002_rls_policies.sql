-- ============================================================
-- DOMINUS — Supabase Migration 002
-- Row Level Security (RLS) Policies
-- Ensures users only see data they're allowed to access
-- ============================================================

-- Enable RLS on all tables
ALTER TABLE profiles             ENABLE ROW LEVEL SECURITY;
ALTER TABLE properties           ENABLE ROW LEVEL SECURITY;
ALTER TABLE property_contracts   ENABLE ROW LEVEL SECURITY;
ALTER TABLE property_members     ENABLE ROW LEVEL SECURITY;
ALTER TABLE checklist_templates  ENABLE ROW LEVEL SECURITY;
ALTER TABLE inspection_visits    ENABLE ROW LEVEL SECURITY;
ALTER TABLE checklist_results    ENABLE ROW LEVEL SECURITY;
ALTER TABLE property_photos      ENABLE ROW LEVEL SECURITY;
ALTER TABLE seasonal_tasks       ENABLE ROW LEVEL SECURITY;
ALTER TABLE seasonal_completions ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations        ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages             ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications        ENABLE ROW LEVEL SECURITY;
ALTER TABLE training_courses     ENABLE ROW LEVEL SECURITY;
ALTER TABLE training_completions ENABLE ROW LEVEL SECURITY;

-- ============================================================
-- HELPER: check if user has access to a property
-- ============================================================

CREATE OR REPLACE FUNCTION user_has_property_access(prop_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM properties      WHERE id = prop_id AND owner_id = auth.uid()
    UNION
    SELECT 1 FROM property_members WHERE property_id = prop_id AND user_id = auth.uid() AND accepted_at IS NOT NULL
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================
-- PROFILES
-- ============================================================

CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT USING (id = auth.uid());

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE USING (id = auth.uid());

-- Property team members can see each other's profiles
CREATE POLICY "Team members can view co-member profiles"
  ON profiles FOR SELECT USING (
    id IN (
      SELECT user_id FROM property_members
      WHERE property_id IN (
        SELECT property_id FROM property_members WHERE user_id = auth.uid()
      )
    )
  );

-- ============================================================
-- PROPERTIES
-- ============================================================

CREATE POLICY "Owners can do everything with their properties"
  ON properties FOR ALL USING (owner_id = auth.uid());

CREATE POLICY "Team members can view assigned properties"
  ON properties FOR SELECT USING (
    id IN (
      SELECT property_id FROM property_members
      WHERE user_id = auth.uid() AND accepted_at IS NOT NULL
    )
  );

-- ============================================================
-- PROPERTY CONTRACTS
-- ============================================================

CREATE POLICY "Property access grants contract access"
  ON property_contracts FOR ALL USING (user_has_property_access(property_id));

-- ============================================================
-- PROPERTY MEMBERS
-- ============================================================

CREATE POLICY "Property owners manage team"
  ON property_members FOR ALL USING (
    property_id IN (SELECT id FROM properties WHERE owner_id = auth.uid())
  );

CREATE POLICY "Members can see their own membership"
  ON property_members FOR SELECT USING (user_id = auth.uid());

-- ============================================================
-- CHECKLIST TEMPLATES
-- ============================================================

CREATE POLICY "Property access grants checklist template access"
  ON checklist_templates FOR ALL USING (user_has_property_access(property_id));

-- ============================================================
-- INSPECTION VISITS
-- ============================================================

CREATE POLICY "Property access grants visit access"
  ON inspection_visits FOR ALL USING (user_has_property_access(property_id));

-- ============================================================
-- CHECKLIST RESULTS
-- ============================================================

CREATE POLICY "Visit access grants result access"
  ON checklist_results FOR ALL USING (
    visit_id IN (
      SELECT id FROM inspection_visits
      WHERE user_has_property_access(property_id)
    )
  );

-- ============================================================
-- PROPERTY PHOTOS
-- ============================================================

CREATE POLICY "Property access grants photo access"
  ON property_photos FOR ALL USING (user_has_property_access(property_id));

-- ============================================================
-- SEASONAL TASKS & COMPLETIONS
-- ============================================================

CREATE POLICY "Property access grants seasonal task access"
  ON seasonal_tasks FOR ALL USING (user_has_property_access(property_id));

CREATE POLICY "Seasonal completion access via task"
  ON seasonal_completions FOR ALL USING (
    task_id IN (
      SELECT id FROM seasonal_tasks
      WHERE user_has_property_access(property_id)
    )
  );

-- ============================================================
-- MESSAGES & CONVERSATIONS
-- ============================================================

CREATE POLICY "Property access grants conversation access"
  ON conversations FOR ALL USING (user_has_property_access(property_id));

CREATE POLICY "Conversation members can read messages"
  ON messages FOR SELECT USING (
    conversation_id IN (
      SELECT id FROM conversations WHERE user_has_property_access(property_id)
    )
  );

CREATE POLICY "Users can send messages to accessible conversations"
  ON messages FOR INSERT WITH CHECK (
    sender_id = auth.uid() AND
    conversation_id IN (
      SELECT id FROM conversations WHERE user_has_property_access(property_id)
    )
  );

-- ============================================================
-- NOTIFICATIONS
-- ============================================================

CREATE POLICY "Users can only see their own notifications"
  ON notifications FOR ALL USING (user_id = auth.uid());

-- ============================================================
-- TRAINING
-- ============================================================

CREATE POLICY "All authenticated users can view courses"
  ON training_courses FOR SELECT USING (auth.uid() IS NOT NULL AND active = TRUE);

CREATE POLICY "Users manage their own completions"
  ON training_completions FOR ALL USING (user_id = auth.uid());

-- ============================================================
-- STORAGE BUCKETS
-- ============================================================

-- Run via Supabase dashboard or CLI after migration
-- supabase storage create property-photos --public
-- supabase storage create inspection-reports --public

INSERT INTO storage.buckets (id, name, public) VALUES
  ('property-photos',     'property-photos',     true),
  ('inspection-reports',  'inspection-reports',  true)
ON CONFLICT DO NOTHING;

CREATE POLICY "Authenticated users can upload photos"
  ON storage.objects FOR INSERT WITH CHECK (
    bucket_id = 'property-photos' AND auth.uid() IS NOT NULL
  );

CREATE POLICY "Anyone can view photos"
  ON storage.objects FOR SELECT USING (bucket_id = 'property-photos');

CREATE POLICY "Uploader can delete their photos"
  ON storage.objects FOR DELETE USING (
    bucket_id = 'property-photos' AND owner = auth.uid()
  );
