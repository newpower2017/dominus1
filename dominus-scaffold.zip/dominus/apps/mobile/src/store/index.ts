// apps/mobile/src/store/index.ts
// Global state with Zustand — lightweight, no boilerplate

import { create } from 'zustand';
import type { Profile, Property, Notification } from '@dominus/shared';

// ── AUTH STORE ───────────────────────────────────────────────────

interface AuthState {
  profile: Profile | null;
  isAuthenticated: boolean;
  setProfile: (profile: Profile | null) => void;
  clearAuth: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  profile: null,
  isAuthenticated: false,
  setProfile: (profile) => set({ profile, isAuthenticated: !!profile }),
  clearAuth: () => set({ profile: null, isAuthenticated: false }),
}));

// ── PROPERTY STORE ───────────────────────────────────────────────

interface PropertyState {
  properties: Property[];
  selectedPropertyId: string | null;
  isLoading: boolean;
  setProperties: (properties: Property[]) => void;
  upsertProperty: (property: Property) => void;
  removeProperty: (id: string) => void;
  selectProperty: (id: string | null) => void;
  setLoading: (loading: boolean) => void;
  getSelected: () => Property | undefined;
}

export const usePropertyStore = create<PropertyState>((set, get) => ({
  properties: [],
  selectedPropertyId: null,
  isLoading: false,
  setProperties: (properties) => set({ properties }),
  upsertProperty: (property) => set((state) => {
    const exists = state.properties.find(p => p.id === property.id);
    return {
      properties: exists
        ? state.properties.map(p => p.id === property.id ? property : p)
        : [...state.properties, property],
    };
  }),
  removeProperty: (id) => set((state) => ({
    properties: state.properties.filter(p => p.id !== id),
  })),
  selectProperty: (id) => set({ selectedPropertyId: id }),
  setLoading: (isLoading) => set({ isLoading }),
  getSelected: () => {
    const { properties, selectedPropertyId } = get();
    return properties.find(p => p.id === selectedPropertyId);
  },
}));

// ── NOTIFICATION STORE ───────────────────────────────────────────

interface NotificationState {
  notifications: Notification[];
  unreadCount: number;
  setNotifications: (notifications: Notification[]) => void;
  markRead: (id: string) => void;
  markAllRead: () => void;
}

export const useNotificationStore = create<NotificationState>((set) => ({
  notifications: [],
  unreadCount: 0,
  setNotifications: (notifications) => set({
    notifications,
    unreadCount: notifications.filter(n => !n.read).length,
  }),
  markRead: (id) => set((state) => {
    const updated = state.notifications.map(n => n.id === id ? { ...n, read: true } : n);
    return { notifications: updated, unreadCount: updated.filter(n => !n.read).length };
  }),
  markAllRead: () => set((state) => ({
    notifications: state.notifications.map(n => ({ ...n, read: true })),
    unreadCount: 0,
  })),
}));
