// apps/mobile/src/screens/SCREEN_MAP.md
//
// Expo Router uses file-based routing (like Next.js).
// Each file in app/ becomes a route.
//
// FILE STRUCTURE:
//
// apps/mobile/app/
// ├── _layout.tsx              ← Root layout (fonts, auth gate, notifications)
// ├── index.tsx                ← Redirect to (auth) or (app) based on session
// │
// ├── (auth)/
// │   ├── _layout.tsx          ← Auth stack layout (no tab bar)
// │   ├── sign-in.tsx          ← Email + password login
// │   ├── sign-up.tsx          ← Register with role selection
// │   └── forgot-password.tsx  ← Password reset
// │
// └── (app)/
//     ├── _layout.tsx          ← Tab bar layout (Home, Reports, Training, Messages)
//     │
//     ├── index.tsx            ← Dashboard (property list with thumbnails & tier badges)
//     │
//     ├── property/
//     │   ├── [id].tsx         ← Property detail (4-tab: Checks, Seasonal, Schedule, Photos)
//     │   ├── [id]/checklist.tsx   ← Weekly checklist panel (week navigator, pass/fail/pending)
//     │   ├── [id]/seasonal.tsx    ← Seasonal checks panel (spring/summer/fall/winter)
//     │   ├── [id]/schedule.tsx    ← Contract & schedule editor
//     │   └── [id]/photos.tsx      ← Photo gallery + capture
//     │
//     ├── reports/
//     │   └── index.tsx        ← All reports, geo-verified, downloadable PDFs
//     │
//     ├── training/
//     │   └── index.tsx        ← Training centre (Foundation / Intermediate / Professional)
//     │
//     └── messages/
//         ├── index.tsx        ← Conversation list
//         └── [conversationId].tsx ← Chat thread with real-time messages

// ── SCREEN COMPONENT TEMPLATE ────────────────────────────────────
//
// Every screen follows this structure:
//
// import { View, ScrollView } from 'react-native';
// import { useLocalSearchParams } from 'expo-router';
// import { usePropertyStore } from '@/store';
// import { PropertyService } from '@/services/api';
//
// export default function PropertyDetailScreen() {
//   const { id } = useLocalSearchParams<{ id: string }>();
//   const property = usePropertyStore(s => s.properties.find(p => p.id === id));
//   // ... render using the Dominus design system (obsidian/gold palette)
// }
//
// ── NAVIGATION FLOW ──────────────────────────────────────────────
//
// App launch
//   → _layout checks session
//   → No session → (auth)/sign-in
//   → Session → (app)/index (Dashboard)
//
// Dashboard
//   → Tap property card → property/[id] (defaults to Checklist tab)
//   → Bottom nav: Home | Reports | Training | Messages
//
// Property detail
//   → Checks tab   → weekly checklist with week navigator
//   → Seasonal tab → 4-season panel with per-property tasks
//   → Schedule tab → contract plan + upcoming visits + Edit Plan modal
//   → Photos tab   → gallery + camera/upload modal
