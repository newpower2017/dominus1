// apps/mobile/src/services/api.ts
// All API calls go through this service layer
// Never call Supabase directly from screens

import { createClient } from '@supabase/supabase-js';
import * as SecureStore from 'expo-secure-store';
import type {
  Property, PropertyContract, InspectionVisit,
  ChecklistTemplate, ChecklistResult, ChecklistStatus,
  PropertyPhoto, SeasonalTask, SeasonKey,
  Message, Notification, Profile
} from '@dominus/shared';

// ── SUPABASE CLIENT (anon key — RLS enforced) ────────────────────

const ExpoSecureStoreAdapter = {
  getItem:    (key: string) => SecureStore.getItemAsync(key),
  setItem:    (key: string, value: string) => SecureStore.setItemAsync(key, value),
  removeItem: (key: string) => SecureStore.deleteItemAsync(key),
};

export const supabase = createClient(
  process.env.EXPO_PUBLIC_SUPABASE_URL!,
  process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!,
  {
    auth: {
      storage: ExpoSecureStoreAdapter,
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: false,
    },
  }
);

// ── API BASE ─────────────────────────────────────────────────────

const API_URL = process.env.EXPO_PUBLIC_API_URL;

async function apiRequest<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const { data: { session } } = await supabase.auth.getSession();
  const token = session?.access_token;

  const response = await fetch(`${API_URL}${endpoint}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token && { Authorization: `Bearer ${token}` }),
      ...options.headers,
    },
  });

  const json = await response.json();
  if (!response.ok) throw new Error(json.error?.message || 'API error');
  return json.data;
}

// ── AUTH ─────────────────────────────────────────────────────────

export const AuthService = {
  signUp: (email: string, password: string, fullName: string, role: string) =>
    supabase.auth.signUp({
      email, password,
      options: { data: { full_name: fullName, role } }
    }),

  signIn: (email: string, password: string) =>
    supabase.auth.signInWithPassword({ email, password }),

  signOut: () => supabase.auth.signOut(),

  getSession: () => supabase.auth.getSession(),

  getProfile: (userId: string) =>
    supabase.from('profiles').select('*').eq('id', userId).single(),
};

// ── PROPERTIES ───────────────────────────────────────────────────

export const PropertyService = {
  list: () =>
    apiRequest<Property[]>('/api/properties'),

  get: (id: string) =>
    apiRequest<Property>(`/api/properties/${id}`),

  create: (data: { name: string; address: string; postcode?: string; geoLat?: number; geoLng?: number }) =>
    apiRequest<Property>('/api/properties', { method: 'POST', body: JSON.stringify(data) }),

  update: (id: string, data: Partial<Property>) =>
    apiRequest<Property>(`/api/properties/${id}`, { method: 'PATCH', body: JSON.stringify(data) }),

  delete: (id: string) =>
    apiRequest<{ deleted: boolean }>(`/api/properties/${id}`, { method: 'DELETE' }),
};

// ── CONTRACTS ────────────────────────────────────────────────────

export const ContractService = {
  get: (propertyId: string) =>
    apiRequest<PropertyContract>(`/api/contracts/${propertyId}`),

  update: (propertyId: string, data: Partial<PropertyContract>) =>
    apiRequest<PropertyContract>(`/api/contracts/${propertyId}`, {
      method: 'PUT', body: JSON.stringify(data)
    }),

  subscribe: (propertyId: string, tier: string) =>
    apiRequest<{ subscriptionId: string; clientSecret: string }>(
      `/api/contracts/${propertyId}/subscribe`,
      { method: 'POST', body: JSON.stringify({ tier }) }
    ),
};

// ── CHECKLIST TEMPLATES ──────────────────────────────────────────

export const ChecklistService = {
  getTemplates: (propertyId: string) =>
    supabase
      .from('checklist_templates')
      .select('*')
      .eq('property_id', propertyId)
      .eq('active', true)
      .order('sort_order'),

  addTemplate: (data: Omit<ChecklistTemplate, 'id' | 'createdAt' | 'updatedAt'>) =>
    supabase.from('checklist_templates').insert(data).select().single(),

  updateTemplate: (id: string, data: Partial<ChecklistTemplate>) =>
    supabase.from('checklist_templates').update(data).eq('id', id).select().single(),

  deleteTemplate: (id: string) =>
    supabase.from('checklist_templates').update({ active: false }).eq('id', id),
};

// ── VISITS ───────────────────────────────────────────────────────

export const VisitService = {
  list: (propertyId: string, limit = 10) =>
    apiRequest<InspectionVisit[]>(`/api/visits?propertyId=${propertyId}&limit=${limit}`),

  getByWeek: (propertyId: string, weekKey: string) =>
    apiRequest<InspectionVisit>(`/api/visits?propertyId=${propertyId}&weekKey=${weekKey}`),

  start: (propertyId: string, weekKey: string, geoLat?: number, geoLng?: number) =>
    apiRequest<InspectionVisit>('/api/visits', {
      method: 'POST',
      body: JSON.stringify({ propertyId, weekKey, geoLat, geoLng })
    }),

  updateResult: (visitId: string, result: {
    templateId: string;
    status: ChecklistStatus;
    inspectorNote?: string;
    photoUrl?: string;
  }) =>
    apiRequest<ChecklistResult>(`/api/visits/${visitId}/result`, {
      method: 'PATCH', body: JSON.stringify(result)
    }),

  submit: (visitId: string) =>
    apiRequest<{ score: number; status: string; failCount: number }>(
      `/api/visits/${visitId}/submit`, { method: 'POST' }
    ),
};

// ── PHOTOS ───────────────────────────────────────────────────────

export const PhotoService = {
  list: (propertyId: string) =>
    apiRequest<PropertyPhoto[]>(`/api/photos?propertyId=${propertyId}`),

  upload: async (propertyId: string, uri: string, label: string, geo?: { lat: number; lng: number }, visitId?: string) => {
    const { data: { session } } = await supabase.auth.getSession();
    const formData = new FormData();
    formData.append('file', { uri, name: 'photo.jpg', type: 'image/jpeg' } as any);
    formData.append('propertyId', propertyId);
    formData.append('label', label);
    if (geo) { formData.append('geoLat', String(geo.lat)); formData.append('geoLng', String(geo.lng)); }
    if (visitId) formData.append('visitId', visitId);

    const response = await fetch(`${API_URL}/api/photos`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${session?.access_token}` },
      body: formData,
    });
    const json = await response.json();
    if (!response.ok) throw new Error(json.error?.message);
    return json.data as PropertyPhoto;
  },

  delete: (id: string) =>
    apiRequest<{ deleted: boolean }>(`/api/photos/${id}`, { method: 'DELETE' }),
};

// ── SEASONAL ─────────────────────────────────────────────────────

export const SeasonalService = {
  getTasks: (propertyId: string, season?: SeasonKey) => {
    const params = new URLSearchParams({ propertyId });
    if (season) params.set('season', season);
    return apiRequest<SeasonalTask[]>(`/api/seasonal?${params}`);
  },

  addTask: (propertyId: string, season: SeasonKey, title: string) =>
    apiRequest<SeasonalTask>('/api/seasonal/task', {
      method: 'POST', body: JSON.stringify({ propertyId, season, title })
    }),

  updateTask: (id: string, data: { title?: string; active?: boolean }) =>
    apiRequest<SeasonalTask>(`/api/seasonal/task/${id}`, {
      method: 'PATCH', body: JSON.stringify(data)
    }),

  complete: (taskId: string, done: boolean, year?: number) =>
    apiRequest('/api/seasonal/complete', {
      method: 'POST', body: JSON.stringify({ taskId, done, year })
    }),
};

// ── MESSAGES ─────────────────────────────────────────────────────

export const MessageService = {
  getConversations: (propertyId: string) =>
    supabase.from('conversations').select('*, messages(*)').eq('property_id', propertyId),

  getMessages: (conversationId: string) =>
    supabase
      .from('messages')
      .select('*, sender:profiles(id, full_name, avatar_url)')
      .eq('conversation_id', conversationId)
      .order('sent_at'),

  send: (conversationId: string, senderId: string, body: string) =>
    supabase.from('messages').insert({ conversation_id: conversationId, sender_id: senderId, body }).select().single(),

  // Real-time subscription
  subscribeToMessages: (conversationId: string, callback: (message: Message) => void) =>
    supabase
      .channel(`messages:${conversationId}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'messages',
        filter: `conversation_id=eq.${conversationId}`,
      }, (payload) => callback(payload.new as Message))
      .subscribe(),
};

// ── NOTIFICATIONS ────────────────────────────────────────────────

export const NotificationService = {
  list: (userId: string) =>
    supabase
      .from('notifications')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(50),

  markRead: (id: string) =>
    supabase.from('notifications').update({ read: true }).eq('id', id),

  markAllRead: (userId: string) =>
    supabase.from('notifications').update({ read: true }).eq('user_id', userId),
};
