// apps/api/src/routes/photos.ts
// Handles photo uploads to Supabase Storage with geo-tagging
import { Router } from 'express';
import multer from 'multer';
import sharp from 'sharp';
import { AuthRequest } from '../middleware/auth';
import { supabaseAdmin } from '../services/supabase';

const router = Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });

// ── GET /api/photos?propertyId= ──────────────────────────────────

router.get('/', async (req: AuthRequest, res) => {
  const { propertyId } = req.query;
  try {
    let query = supabaseAdmin
      .from('property_photos')
      .select('*')
      .order('uploaded_at', { ascending: false });

    if (propertyId) query = query.eq('property_id', propertyId);

    const { data, error } = await query;
    if (error) throw error;
    res.json({ data });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'FETCH_ERROR', message: err.message } });
  }
});

// ── POST /api/photos ─────────────────────────────────────────────
// Accepts multipart/form-data with: file, propertyId, label, geoLat, geoLng, visitId

router.post('/', upload.single('file'), async (req: AuthRequest, res) => {
  const { propertyId, label, geoLat, geoLng, visitId } = req.body;

  if (!req.file || !propertyId) {
    return res.status(400).json({ error: { code: 'VALIDATION', message: 'file and propertyId are required' } });
  }

  try {
    // Resize & optimise with sharp
    const optimised = await sharp(req.file.buffer)
      .resize(1200, 900, { fit: 'inside', withoutEnlargement: true })
      .jpeg({ quality: 85 })
      .toBuffer();

    // Build storage path: property-photos/{propertyId}/{timestamp}.jpg
    const timestamp = Date.now();
    const storagePath = `${propertyId}/${timestamp}.jpg`;

    // Upload to Supabase Storage
    const { error: uploadError } = await supabaseAdmin.storage
      .from('property-photos')
      .upload(storagePath, optimised, { contentType: 'image/jpeg', upsert: false });

    if (uploadError) throw uploadError;

    // Get public URL
    const { data: { publicUrl } } = supabaseAdmin.storage
      .from('property-photos')
      .getPublicUrl(storagePath);

    // Record in database
    const { data, error } = await supabaseAdmin
      .from('property_photos')
      .insert({
        property_id: propertyId,
        visit_id: visitId || null,
        storage_path: storagePath,
        public_url: publicUrl,
        label: label || 'Property photo',
        geo_lat: geoLat ? parseFloat(geoLat) : null,
        geo_lng: geoLng ? parseFloat(geoLng) : null,
        geo_timestamp: geoLat ? new Date().toISOString() : null,
        uploaded_by: req.userId,
      })
      .select()
      .single();

    if (error) throw error;
    res.status(201).json({ data });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'UPLOAD_ERROR', message: err.message } });
  }
});

// ── DELETE /api/photos/:id ───────────────────────────────────────

router.delete('/:id', async (req: AuthRequest, res) => {
  try {
    const { data: photo } = await supabaseAdmin
      .from('property_photos')
      .select('storage_path')
      .eq('id', req.params.id)
      .single();

    if (photo?.storage_path) {
      await supabaseAdmin.storage.from('property-photos').remove([photo.storage_path]);
    }

    const { error } = await supabaseAdmin
      .from('property_photos')
      .delete()
      .eq('id', req.params.id)
      .eq('uploaded_by', req.userId);

    if (error) throw error;
    res.json({ data: { deleted: true } });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'DELETE_ERROR', message: err.message } });
  }
});

export default router;
