// apps/api/src/routes/seasonal.ts
import { Router } from 'express';
import { AuthRequest } from '../middleware/auth';
import { supabaseAdmin } from '../services/supabase';

const router = Router();
const CURRENT_YEAR = new Date().getFullYear();

// ── GET /api/seasonal?propertyId=&season= ───────────────────────
// Returns tasks with completion status for current year

router.get('/', async (req: AuthRequest, res) => {
  const { propertyId, season } = req.query;
  const year = parseInt(req.query.year as string) || CURRENT_YEAR;

  try {
    let query = supabaseAdmin
      .from('seasonal_tasks')
      .select(`*, completions:seasonal_completions(done, done_at, year)`)
      .eq('active', true)
      .order('sort_order');

    if (propertyId) query = query.eq('property_id', propertyId);
    if (season)     query = query.eq('season', season);

    const { data, error } = await query;
    if (error) throw error;

    // Flatten completion status for the requested year
    const tasks = (data || []).map((task: any) => ({
      ...task,
      done: task.completions?.find((c: any) => c.year === year)?.done || false,
      completions: undefined,
    }));

    res.json({ data: tasks });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'FETCH_ERROR', message: err.message } });
  }
});

// ── POST /api/seasonal/task ──────────────────────────────────────
// Add a custom seasonal task to a property

router.post('/task', async (req: AuthRequest, res) => {
  const { propertyId, season, title } = req.body;

  if (!propertyId || !season || !title) {
    return res.status(400).json({ error: { code: 'VALIDATION', message: 'propertyId, season, and title are required' } });
  }

  try {
    const { data, error } = await supabaseAdmin
      .from('seasonal_tasks')
      .insert({ property_id: propertyId, season, title })
      .select()
      .single();

    if (error) throw error;
    res.status(201).json({ data });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'CREATE_ERROR', message: err.message } });
  }
});

// ── PATCH /api/seasonal/task/:id ─────────────────────────────────
// Edit task title or deactivate (soft delete)

router.patch('/task/:id', async (req: AuthRequest, res) => {
  const { title, active } = req.body;
  try {
    const { data, error } = await supabaseAdmin
      .from('seasonal_tasks')
      .update({ title, active })
      .eq('id', req.params.id)
      .select()
      .single();

    if (error) throw error;
    res.json({ data });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'UPDATE_ERROR', message: err.message } });
  }
});

// ── POST /api/seasonal/complete ──────────────────────────────────
// Mark a task done/undone for a given year

router.post('/complete', async (req: AuthRequest, res) => {
  const { taskId, done } = req.body;
  const year = parseInt(req.body.year) || CURRENT_YEAR;

  if (!taskId) {
    return res.status(400).json({ error: { code: 'VALIDATION', message: 'taskId is required' } });
  }

  try {
    const { data, error } = await supabaseAdmin
      .from('seasonal_completions')
      .upsert({
        task_id: taskId,
        year,
        done: done !== false,
        done_at: done !== false ? new Date().toISOString() : null,
        done_by: req.userId,
      }, { onConflict: 'task_id,year' })
      .select()
      .single();

    if (error) throw error;
    res.json({ data });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'COMPLETE_ERROR', message: err.message } });
  }
});

export default router;
