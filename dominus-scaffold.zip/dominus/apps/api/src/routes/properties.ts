// apps/api/src/routes/properties.ts
import { Router } from 'express';
import { AuthRequest } from '../middleware/auth';
import { supabaseAdmin } from '../services/supabase';

const router = Router();

// ── DEFAULT DATA (auto-seeded on property creation) ──────────────

const DEFAULT_CHECKLIST_ITEMS = [
  { title: 'All entry points locked & verified',    category: 'Security',   priority: 'critical', sort_order: 1  },
  { title: 'CCTV systems operational',              category: 'Security',   priority: 'high',     sort_order: 2  },
  { title: 'No leaks under kitchen & bath fixtures',category: 'Water',      priority: 'critical', sort_order: 3  },
  { title: 'Water pressure within normal range',    category: 'Water',      priority: 'medium',   sort_order: 4  },
  { title: 'Smoke & CO detectors tested',           category: 'Electrical', priority: 'high',     sort_order: 5  },
  { title: 'HVAC & climate system active',          category: 'Electrical', priority: 'medium',   sort_order: 6  },
  { title: 'No signs of forced entry or damage',    category: 'Exterior',   priority: 'high',     sort_order: 7  },
  { title: 'Drainage & gutters clear',              category: 'Exterior',   priority: 'low',      sort_order: 8  },
  { title: 'No damp or mould indicators',           category: 'Interior',   priority: 'high',     sort_order: 9  },
  { title: 'Heating system functioning',            category: 'Interior',   priority: 'medium',   sort_order: 10 },
];

const DEFAULT_SEASONAL_TASKS = {
  spring: [
    'Open & test outdoor water taps and irrigation',
    'Power-wash patios, terraces & pathways',
    'Bring out & inspect outdoor furniture',
    'Clean & treat outdoor furniture surfaces',
    'Check exterior paintwork for winter damage',
    'Service lawn equipment & garden tools',
    'Inspect roof & gutters post-winter',
    'Test outdoor lighting & security cameras',
  ],
  summer: [
    'Service air conditioning & cooling systems',
    'Check pool or water feature equipment',
    'Inspect window seals & draught-proofing',
    'Test sprinkler & irrigation schedules',
    'Check sun blinds, awnings & pergola structure',
    'Inspect decking for splinters or weathering',
  ],
  fall: [
    'Clear gutters & drains of fallen leaves',
    'Service boiler & central heating before use',
    'Drain & winterise outdoor water taps',
    'Store outdoor furniture in dry conditions',
    'Inspect chimney & fireplace before first use',
    'Check window & door weather-sealing',
    'Trim trees & branches near the property',
  ],
  winter: [
    'Insulate exposed pipes to prevent freezing',
    'Check roof for snow load or ice dams',
    'Test emergency generator & backup heating',
    'Verify carbon monoxide detectors are working',
    'Inspect loft & attic insulation levels',
    'Stock emergency kit — salt, torch, first aid',
  ],
};

// ── GET /api/properties ──────────────────────────────────────────
// Returns all properties the authenticated user can access

router.get('/', async (req: AuthRequest, res) => {
  try {
    const { data, error } = await supabaseAdmin
      .from('properties')
      .select(`
        *,
        contract:property_contracts(*),
        photos:property_photos(id, public_url, label, uploaded_at)
      `)
      .or(`owner_id.eq.${req.userId},id.in.(
        select property_id from property_members where user_id = '${req.userId}' and accepted_at is not null
      )`)
      .order('created_at', { ascending: false });

    if (error) throw error;
    res.json({ data });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'FETCH_ERROR', message: err.message } });
  }
});

// ── GET /api/properties/:id ──────────────────────────────────────

router.get('/:id', async (req: AuthRequest, res) => {
  try {
    const { data, error } = await supabaseAdmin
      .from('properties')
      .select(`
        *,
        contract:property_contracts(*),
        photos:property_photos(*),
        checklist_templates(*),
        members:property_members(*, profile:profiles(id, full_name, role, avatar_url))
      `)
      .eq('id', req.params.id)
      .single();

    if (error) throw error;
    if (!data) return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Property not found' } });

    res.json({ data });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'FETCH_ERROR', message: err.message } });
  }
});

// ── POST /api/properties ─────────────────────────────────────────
// Creates property + auto-seeds checklist templates + seasonal tasks

router.post('/', async (req: AuthRequest, res) => {
  const { name, address, postcode, country, geoLat, geoLng } = req.body;

  if (!name || !address) {
    return res.status(400).json({ error: { code: 'VALIDATION', message: 'name and address are required' } });
  }

  try {
    // 1. Create property
    const { data: property, error: propError } = await supabaseAdmin
      .from('properties')
      .insert({
        name,
        address,
        postcode,
        country: country || 'GB',
        geo_lat: geoLat,
        geo_lng: geoLng,
        owner_id: req.userId,
      })
      .select()
      .single();

    if (propError) throw propError;

    // 2. Seed default checklist templates
    const templates = DEFAULT_CHECKLIST_ITEMS.map(item => ({
      ...item,
      property_id: property.id,
    }));

    await supabaseAdmin.from('checklist_templates').insert(templates);

    // 3. Seed seasonal tasks
    const seasonalRows: any[] = [];
    let sortOrder = 1;
    for (const [season, tasks] of Object.entries(DEFAULT_SEASONAL_TASKS)) {
      tasks.forEach(title => {
        seasonalRows.push({ property_id: property.id, season, title, sort_order: sortOrder++ });
      });
    }
    await supabaseAdmin.from('seasonal_tasks').insert(seasonalRows);

    // 4. Create default Essential contract
    await supabaseAdmin.from('property_contracts').insert({
      property_id: property.id,
      plan: 'monthly',
      tier: 'Essential',
    });

    res.status(201).json({ data: property });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'CREATE_ERROR', message: err.message } });
  }
});

// ── PATCH /api/properties/:id ────────────────────────────────────

router.patch('/:id', async (req: AuthRequest, res) => {
  const { name, address, postcode, status, score } = req.body;
  try {
    const { data, error } = await supabaseAdmin
      .from('properties')
      .update({ name, address, postcode, status, score })
      .eq('id', req.params.id)
      .eq('owner_id', req.userId)   // only owner can update
      .select()
      .single();

    if (error) throw error;
    res.json({ data });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'UPDATE_ERROR', message: err.message } });
  }
});

// ── DELETE /api/properties/:id ───────────────────────────────────

router.delete('/:id', async (req: AuthRequest, res) => {
  try {
    const { error } = await supabaseAdmin
      .from('properties')
      .delete()
      .eq('id', req.params.id)
      .eq('owner_id', req.userId);

    if (error) throw error;
    res.json({ data: { deleted: true } });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'DELETE_ERROR', message: err.message } });
  }
});

export default router;
