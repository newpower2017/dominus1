// apps/api/src/routes/contracts.ts
import { Router } from 'express';
import Stripe from 'stripe';
import { AuthRequest } from '../middleware/auth';
import { supabaseAdmin } from '../services/supabase';

const router = Router();

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2023-10-16' });

// Stripe Price IDs — create these in your Stripe dashboard
// and paste the IDs here (or store in env vars)
const STRIPE_PRICES: Record<string, string> = {
  Essential: process.env.STRIPE_PRICE_ESSENTIAL || 'price_xxx_essential',
  Standard:  process.env.STRIPE_PRICE_STANDARD  || 'price_xxx_standard',
  Premium:   process.env.STRIPE_PRICE_PREMIUM   || 'price_xxx_premium',
};

// ── GET /api/contracts/:propertyId ──────────────────────────────

router.get('/:propertyId', async (req: AuthRequest, res) => {
  try {
    const { data, error } = await supabaseAdmin
      .from('property_contracts')
      .select('*')
      .eq('property_id', req.params.propertyId)
      .single();

    if (error) throw error;
    res.json({ data });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'FETCH_ERROR', message: err.message } });
  }
});

// ── PUT /api/contracts/:propertyId ──────────────────────────────
// Update contract schedule (plan, tier, notes, etc.)

router.put('/:propertyId', async (req: AuthRequest, res) => {
  const {
    plan,
    tier,
    customIntervalDays,
    contractHolder,
    inspectorNotes,
  } = req.body;

  try {
    const { data, error } = await supabaseAdmin
      .from('property_contracts')
      .upsert({
        property_id: req.params.propertyId,
        plan,
        tier,
        custom_interval_days: customIntervalDays,
        contract_holder: contractHolder,
        inspector_notes: inspectorNotes,
      }, { onConflict: 'property_id' })
      .select()
      .single();

    if (error) throw error;
    res.json({ data });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'UPDATE_ERROR', message: err.message } });
  }
});

// ── POST /api/contracts/:propertyId/subscribe ───────────────────
// Create or upgrade a Stripe subscription for a property

router.post('/:propertyId/subscribe', async (req: AuthRequest, res) => {
  const { tier } = req.body;
  const priceId = STRIPE_PRICES[tier];

  if (!priceId) {
    return res.status(400).json({ error: { code: 'VALIDATION', message: 'Invalid tier' } });
  }

  try {
    // Get or create Stripe customer for this user
    const { data: profile } = await supabaseAdmin
      .from('profiles')
      .select('stripe_customer_id, full_name')
      .eq('id', req.userId)
      .single();

    let customerId = profile?.stripe_customer_id;

    if (!customerId) {
      const { data: userRecord } = await supabaseAdmin.auth.admin.getUserById(req.userId!);
      const customer = await stripe.customers.create({
        email: userRecord.user?.email,
        name: profile?.full_name,
        metadata: { supabase_user_id: req.userId! },
      });
      customerId = customer.id;

      await supabaseAdmin
        .from('profiles')
        .update({ stripe_customer_id: customerId })
        .eq('id', req.userId);
    }

    // Create subscription
    const subscription = await stripe.subscriptions.create({
      customer: customerId,
      items: [{ price: priceId }],
      metadata: { property_id: req.params.propertyId },
      payment_behavior: 'default_incomplete',
      expand: ['latest_invoice.payment_intent'],
    });

    // Store subscription ID on contract
    await supabaseAdmin
      .from('property_contracts')
      .update({
        stripe_subscription_id: subscription.id,
        stripe_price_id: priceId,
        tier,
      })
      .eq('property_id', req.params.propertyId);

    const invoice = subscription.latest_invoice as Stripe.Invoice;
    const paymentIntent = invoice.payment_intent as Stripe.PaymentIntent;

    res.json({
      data: {
        subscriptionId: subscription.id,
        clientSecret: paymentIntent.client_secret,
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'STRIPE_ERROR', message: err.message } });
  }
});

export default router;
