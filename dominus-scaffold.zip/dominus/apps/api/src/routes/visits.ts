// apps/api/src/routes/visits.ts
import { Router } from 'express';
import { AuthRequest } from '../middleware/auth';
import { supabaseAdmin } from '../services/supabase';

const router = Router();

// ── GET /api/visits?propertyId=&weekKey= ─────────────────────────

router.get('/', async (req: AuthRequest, res) => {
  const { propertyId, weekKey, limit = 10 } = req.query;

  try {
    let query = supabaseAdmin
      .from('inspection_visits')
      .select(`*, results:checklist_results(*, template:checklist_templates(*))`)
      .order('visit_date', { ascending: false })
      .limit(Number(limit));

    if (propertyId) query = query.eq('property_id', propertyId);
    if (weekKey)    query = query.eq('week_key', weekKey);

    const { data, error } = await query;
    if (error) throw error;
    res.json({ data });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'FETCH_ERROR', message: err.message } });
  }
});

// ── GET /api/visits/:id ──────────────────────────────────────────

router.get('/:id', async (req: AuthRequest, res) => {
  try {
    const { data, error } = await supabaseAdmin
      .from('inspection_visits')
      .select(`*, results:checklist_results(*, template:checklist_templates(*))`)
      .eq('id', req.params.id)
      .single();

    if (error) throw error;
    res.json({ data });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'FETCH_ERROR', message: err.message } });
  }
});

// ── POST /api/visits ─────────────────────────────────────────────
// Start a new inspection visit (or return existing for this week)

router.post('/', async (req: AuthRequest, res) => {
  const { propertyId, weekKey, geoLat, geoLng } = req.body;

  if (!propertyId || !weekKey) {
    return res.status(400).json({ error: { code: 'VALIDATION', message: 'propertyId and weekKey are required' } });
  }

  try {
    // Check if visit already exists for this week
    const { data: existing } = await supabaseAdmin
      .from('inspection_visits')
      .select('*')
      .eq('property_id', propertyId)
      .eq('week_key', weekKey)
      .single();

    if (existing) return res.json({ data: existing });

    // Create new visit
    const { data, error } = await supabaseAdmin
      .from('inspection_visits')
      .insert({
        property_id: propertyId,
        inspector_id: req.userId,
        week_key: weekKey,
        visit_date: new Date().toISOString().split('T')[0],
        geo_lat: geoLat,
        geo_lng: geoLng,
        geo_verified: !!(geoLat && geoLng),
        geo_timestamp: geoLat ? new Date().toISOString() : null,
      })
      .select()
      .single();

    if (error) throw error;
    res.status(201).json({ data });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'CREATE_ERROR', message: err.message } });
  }
});

// ── PATCH /api/visits/:id/result ─────────────────────────────────
// Update a single checklist item result

router.patch('/:id/result', async (req: AuthRequest, res) => {
  const { templateId, status, inspectorNote, photoUrl } = req.body;

  if (!templateId || !status) {
    return res.status(400).json({ error: { code: 'VALIDATION', message: 'templateId and status are required' } });
  }

  try {
    const { data, error } = await supabaseAdmin
      .from('checklist_results')
      .upsert({
        visit_id: req.params.id,
        template_id: templateId,
        status,
        inspector_note: inspectorNote,
        photo_url: photoUrl,
        recorded_at: new Date().toISOString(),
      }, { onConflict: 'visit_id,template_id' })
      .select()
      .single();

    if (error) throw error;
    res.json({ data });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'UPDATE_ERROR', message: err.message } });
  }
});

// ── POST /api/visits/:id/submit ──────────────────────────────────
// Finalise a visit: calculate score, update property, trigger report

router.post('/:id/submit', async (req: AuthRequest, res) => {
  const visitId = req.params.id;

  try {
    // 1. Get all results for this visit
    const { data: results } = await supabaseAdmin
      .from('checklist_results')
      .select('*, template:checklist_templates(priority)')
      .eq('visit_id', visitId);

    // 2. Calculate weighted score
    const priorityWeights = { critical: 4, high: 3, medium: 2, low: 1 };
    let totalWeight = 0;
    let passWeight = 0;

    (results || []).forEach((r: any) => {
      const weight = priorityWeights[r.template?.priority as keyof typeof priorityWeights] || 1;
      totalWeight += weight;
      if (r.status === 'pass') passWeight += weight;
    });

    const score = totalWeight > 0 ? Math.round((passWeight / totalWeight) * 100) : 0;
    const failCount = (results || []).filter((r: any) => r.status === 'fail').length;
    const propertyStatus = score >= 90 ? 'good' : score >= 70 ? 'attention' : 'overdue';

    // 3. Submit visit
    const { data: visit } = await supabaseAdmin
      .from('inspection_visits')
      .update({ submitted_at: new Date().toISOString(), score })
      .eq('id', visitId)
      .select('property_id')
      .single();

    // 4. Update property score and status
    if (visit?.property_id) {
      await supabaseAdmin
        .from('properties')
        .update({ score, status: propertyStatus, last_check_at: new Date().toISOString() })
        .eq('id', visit.property_id);
    }

    // 5. If issues found, create notifications for property owner
    if (failCount > 0 && visit?.property_id) {
      const { data: property } = await supabaseAdmin
        .from('properties')
        .select('owner_id, name')
        .eq('id', visit.property_id)
        .single();

      if (property) {
        await supabaseAdmin.from('notifications').insert({
          user_id: property.owner_id,
          property_id: visit.property_id,
          title: `${failCount} issue${failCount > 1 ? 's' : ''} found at ${property.name}`,
          body: `This week's inspection flagged ${failCount} item${failCount > 1 ? 's' : ''} that need attention.`,
          type: 'issue_flagged',
          data: { visitId, failCount, score },
        });
      }
    }

    res.json({ data: { score, status: propertyStatus, failCount } });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'SUBMIT_ERROR', message: err.message } });
  }
});

export default router;
