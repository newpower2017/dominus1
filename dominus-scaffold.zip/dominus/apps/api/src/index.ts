// apps/api/src/index.ts
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import { json } from 'body-parser';
import dotenv from 'dotenv';

import { authMiddleware } from './middleware/auth';
import { errorHandler } from './middleware/errorHandler';
import { rateLimiter } from './middleware/rateLimiter';

import authRoutes        from './routes/auth';
import propertiesRoutes  from './routes/properties';
import contractsRoutes   from './routes/contracts';
import checklistRoutes   from './routes/checklist';
import visitsRoutes      from './routes/visits';
import photosRoutes      from './routes/photos';
import seasonalRoutes    from './routes/seasonal';
import messagesRoutes    from './routes/messages';
import reportsRoutes     from './routes/reports';
import notificationsRoutes from './routes/notifications';
import trainingRoutes    from './routes/training';
import stripeRoutes      from './routes/stripe';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// ── MIDDLEWARE ────────────────────────────────────────────────────

app.use(helmet());
app.use(cors({
  origin: [
    'http://localhost:19006',       // Expo web
    'http://localhost:8081',        // Metro bundler
    process.env.PRODUCTION_URL || ''
  ],
  credentials: true,
}));
app.use(morgan('combined'));
app.use(rateLimiter);

// Stripe webhook needs raw body — must be before json()
app.use('/api/stripe/webhook', express.raw({ type: 'application/json' }));
app.use(json({ limit: '10mb' }));

// ── HEALTH CHECK ─────────────────────────────────────────────────

app.get('/health', (_, res) => {
  res.json({ status: 'ok', version: '1.0.0', timestamp: new Date().toISOString() });
});

// ── PUBLIC ROUTES (no auth required) ────────────────────────────

app.use('/api/auth',   authRoutes);
app.use('/api/stripe', stripeRoutes);  // webhook is public

// ── PROTECTED ROUTES ─────────────────────────────────────────────

app.use('/api', authMiddleware);

app.use('/api/properties',    propertiesRoutes);
app.use('/api/contracts',     contractsRoutes);
app.use('/api/checklist',     checklistRoutes);
app.use('/api/visits',        visitsRoutes);
app.use('/api/photos',        photosRoutes);
app.use('/api/seasonal',      seasonalRoutes);
app.use('/api/messages',      messagesRoutes);
app.use('/api/reports',       reportsRoutes);
app.use('/api/notifications', notificationsRoutes);
app.use('/api/training',      trainingRoutes);

// ── ERROR HANDLER (must be last) ─────────────────────────────────

app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`🏛  Dominus API running on port ${PORT}`);
});

export default app;
