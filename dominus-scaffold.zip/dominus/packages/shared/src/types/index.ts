// packages/shared/src/types/index.ts
// Single source of truth for all domain types
// Used by both mobile app and API

export type UserRole = 'manager' | 'homeowner' | 'inspector';
export type PropertyStatus = 'good' | 'attention' | 'overdue';
export type VisitPlan = 'weekly' | 'biweekly' | 'monthly' | 'custom';
export type ContractTier = 'Essential' | 'Standard' | 'Premium' | 'Bespoke';
export type ChecklistStatus = 'pending' | 'pass' | 'fail';
export type PriorityLevel = 'critical' | 'high' | 'medium' | 'low';
export type ChecklistCategory = 'Security' | 'Water' | 'Electrical' | 'Exterior' | 'Interior' | 'Other';
export type SeasonKey = 'spring' | 'summer' | 'fall' | 'winter';
export type ReportType = 'routine' | 'maintenance' | 'insurance' | 'seasonal';

// ── PROFILE ──────────────────────────────────────────────────────

export interface Profile {
  id: string;
  fullName: string;
  role: UserRole;
  phone?: string;
  avatarUrl?: string;
  stripeCustomerId?: string;
  createdAt: string;
  updatedAt: string;
}

// ── PROPERTY ─────────────────────────────────────────────────────

export interface GeoLocation {
  lat: number;
  lng: number;
  timestamp?: string;
  verified?: boolean;
}

export interface Property {
  id: string;
  name: string;
  address: string;
  postcode?: string;
  country: string;
  geo?: GeoLocation;
  illustrationId: number;
  status: PropertyStatus;
  score: number;
  lastCheckAt?: string;
  ownerId: string;
  contract?: PropertyContract;
  createdAt: string;
  updatedAt: string;
}

// ── CONTRACT ─────────────────────────────────────────────────────

export interface PropertyContract {
  id: string;
  propertyId: string;
  plan: VisitPlan;
  tier: ContractTier;
  customIntervalDays?: number;
  contractHolder?: string;
  inspectorNotes?: string;
  startDate: string;
  stripeSubscriptionId?: string;
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

// ── CHECKLIST ────────────────────────────────────────────────────

export interface ChecklistTemplate {
  id: string;
  propertyId: string;
  title: string;
  category: ChecklistCategory;
  priority: PriorityLevel;
  active: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

export interface InspectionVisit {
  id: string;
  propertyId: string;
  inspectorId?: string;
  weekKey: string;       // "2026-W25"
  visitDate: string;
  geo?: GeoLocation;
  geoVerified: boolean;
  score?: number;
  submittedAt?: string;
  reportUrl?: string;
  notes?: string;
  results?: ChecklistResult[];
  createdAt: string;
}

export interface ChecklistResult {
  id: string;
  visitId: string;
  templateId: string;
  status: ChecklistStatus;
  inspectorNote?: string;
  photoUrl?: string;
  recordedAt: string;
}

// ── PHOTOS ───────────────────────────────────────────────────────

export interface PropertyPhoto {
  id: string;
  propertyId: string;
  visitId?: string;
  storagePath: string;
  publicUrl: string;
  label?: string;
  geo?: GeoLocation;
  uploadedBy?: string;
  uploadedAt: string;
}

// ── SEASONAL ─────────────────────────────────────────────────────

export interface SeasonalTask {
  id: string;
  propertyId: string;
  season: SeasonKey;
  title: string;
  active: boolean;
  sortOrder: number;
  createdAt: string;
  done?: boolean;        // joined from seasonal_completions for current year
}

export interface SeasonalCompletion {
  id: string;
  taskId: string;
  year: number;
  done: boolean;
  doneAt?: string;
  doneBy?: string;
}

// ── MESSAGES ─────────────────────────────────────────────────────

export interface Conversation {
  id: string;
  propertyId: string;
  subject?: string;
  lastMessage?: Message;
  createdAt: string;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  sender?: Profile;
  body: string;
  readBy: string[];
  attachmentUrl?: string;
  sentAt: string;
}

// ── NOTIFICATIONS ────────────────────────────────────────────────

export type NotificationType =
  | 'overdue_check'
  | 'issue_flagged'
  | 'message'
  | 'report_ready'
  | 'seasonal_due';

export interface Notification {
  id: string;
  userId: string;
  propertyId?: string;
  title: string;
  body: string;
  type: NotificationType;
  read: boolean;
  data: Record<string, unknown>;
  createdAt: string;
}

// ── API RESPONSES ────────────────────────────────────────────────

export interface ApiResponse<T> {
  data: T;
  error?: never;
}

export interface ApiError {
  data?: never;
  error: {
    code: string;
    message: string;
    details?: unknown;
  };
}

export type ApiResult<T> = ApiResponse<T> | ApiError;

// ── PAGINATION ───────────────────────────────────────────────────

export interface PaginatedResult<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
  hasMore: boolean;
}
